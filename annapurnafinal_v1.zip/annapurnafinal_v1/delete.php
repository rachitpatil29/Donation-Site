<?php
session_start();

$con = mysqli_connect('localhost','root');
if($con){

	echo "connection successful !!!!";

}else{

	echo "no connection";
}
$db = mysqli_select_db($con,'annapurna');

if(isset($_POST['submit'])){

	$tokennumber = $_POST['tokennumber'];


	$sql = "select * from donors where tokennumber='$tokennumber'";

	$query = mysqli_query($con,$sql);

	$row = mysqli_num_rows($query);

		if($row == 1){
			$sql = "UPDATE donors
					SET status = 'yes'
					WHERE tokennumber='$tokennumber'";
			$myquery = mysqli_query($con,$sql);

			$_SESSION['id'] = $tokennumber;
			header("location:ngoprofile.php");

		}
		else{
				echo "login failed";
				header('location:checkentry.html');
			}

	}


?>