  <?php
include_once 'verify.php';
if($_GET){
  $tokennumber = $_GET['tokennumber'];
}
$conn = mysqli_connect("localhost", "root", "", "annapurna");
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM donors where tokennumber='$tokennumber'";
$result = $conn->query($sql);
$row = $result->fetch_assoc()

?>

<!doctype html>
<html lang="en">
  <head>
 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/yes.css">

   
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>Annapurna online donation site</title>
  </head>
  <body>
    <!-- <div class="yes" id="header">
        <a href="/index.html">
            <img src="logo.png" id="logo" class="logo logo1"></a>
            <button id="btn" class="btn btn1">Donate</button>
    </div>  -->
    <div class="yes">
        <a class="navbar-brand"  href="index.html">
      <img src="logo.png" id="logo" alt="">
    </a>
    
  
 
     </div>
  
  
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <!-- <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
       -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent" id="no1">
          <ul class="navbar-nav mr-auto" id="no">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link" href="viewdetails.html">View Details</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="money.html">Donate money</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.html">About us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contactus.html">Contact us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="faq.html">FAQ</a>
            </li>
           
          </ul>
          
        </div>
      </nav>
      
      
      <div class="container my-2">



      	<div class="card-body">
                   <u> <h2 class="title">HELLO <?php echo $row['name']; ?>!! YOUR PROFILE PAGE</h2></u>
                    <form action="delete.php" method="GET">
                        <div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Tokken number :</label>
                                   <label class="label" name="tokennumber">
                                     <?php
                                     echo $row['tokennumber'];
                                     ?>
                                   </label>
                                </div>
                            </div>
                            
                        
							<div class="col-2">
                                <div class="input-group">
                                    <label class="label">Location :</label>
                                    <div class="input-group-icon">
                                      <label for="">
                                        <?php
                                          echo $row['location'];
                                        ?>
                                      </label>
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                    </div>
                                </div>
                            </div>
                           
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Things to donate :</label>
                                    <label for="">
                                      <?php
                                        echo $row['thingsdonated'];
                                      ?>
                                    </label>
                                </div>
                            </div>
                        </div>
							<div class="col-2">
                                <div class="input-group">
                                    <label class="label">Quantity :</label>
                                    <label for="">
                                      <?php
                                        echo $row['amountdonated'];
                                      ?>
                                    </label>
                                </div>
                                <input type="submit" class="submit" name="submit" value="Delete">

                            </div>
							
                            </div>
                    </form>
                </div>

                </div>

      <div class="cointainer bg-dark">
        <footer class="bd-footer text-muted">
          <div class="container-fluid p-2 p-md-3">
           
            
            <p>Currently all copyrights reserved to<a href="#"> @annapurna.com</a></p>
          </div>
        </footer>
      
      </div>
         
  
      
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    </body>
  </html>

        