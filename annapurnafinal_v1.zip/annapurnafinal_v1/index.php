<?php
include_once 'dbh.php'; 
?>

<!doctype html>
<html lang="en">
  <head>
 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/yes.css">

   
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>Annapurna online donation site</title>
  </head>
  <body>
    <!-- <div class="yes" id="header">
        <a href="/index.html">
            <img src="logo.png" id="logo" class="logo logo1"></a>
            <button id="btn" class="btn btn1">Donate</button>
    </div>  -->
    <div class="yes">
        <a class="navbar-brand"  href="index.html">
      <img src="logo.png" id="logo" alt="">
    </a>
    <a href="Donate.html">  <button type="button" class="btn btn-primary btn-lg" id="btn">Donate</button></a>
  
 
     </div>
  
  
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <!-- <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
       -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent" id="no1">
          <ul class="navbar-nav mr-auto" id="no">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link" href="viewdetails.html">View Details</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="money.html">Donate money</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.html">About us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contactus.html">Contact us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="faq.html">FAQ</a>
            </li>
           
          </ul>
          <form class="form-inline my-2 my-lg-0">
          
            <a href="login.html"><button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal">
              Login
            </button></a>
          </form>
        </div>
      </nav>
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            
            </div>
          </div>
        </div>
      </div>
        

      <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
          <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="https://source.unsplash.com/1400x350/?nature,water" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Annapurna donation</h5>
              <a href="Donate.html">
                <button type="button" class="btn btn-warning">Donate now</button>
                </a>
              
              <p>“ No one has ever become poor by giving.” ....</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="https://source.unsplash.com/1400x350/?nature,helping" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Annapurna donation</h5>
                <a href="Donate.html">
                  <button type="button" class="btn btn-warning">Donate now</button>
                  </a>
              <p>“ Remember that the happiest people are not those getting more, but those giving more.” ...</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="https://source.unsplash.com/1400x350/?nature,fire" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>Annapurna donation</h5>
                <a href="Donate.html">
                  <button type="button" class="btn btn-warning">Donate now</button>
                  </a>
              <p>“We make a living by what we get. We make a life by what we give.” </p>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
      <div>
    
    <?php
      $sql = "SELECT * from donors WHERE status='yes'";
      $result = mysqli_query($conn,$sql);
      $datas = array();
      if(mysqli_num_rows($result)>0){
        while($row = mysqli_fetch_assoc($result)){
          $name[] = $row['name'];
          $location[] = $row['location'];
          $thingsDonated[] = $row['thingsdonated'];
          $amountDonated[] = $row['amountdonated'];
        }
      }

    $len = count($name);
    // echo $len;
    for($i=0; $i<$len; $i++){
      if($i%2==1){
        
      }
      else{
    ?>
    
    <div>
          <container>
            <div class="row mb-2 my-3 ml-3 mr-3" >
              <div class="col-md-6">
                <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                  <div class="col p-4 d-flex flex-column position-static">
                  
                    <h3 class="mb-0" ><?php 
                                      echo $name[$i];
                                      ?>
                    </h3>
                    <div class="mb-1 text-muted">From <?php echo $location[$i];?></div>
                    <p class="card-text mb-auto">Donated <?php 
                                                          echo $thingsDonated[$i]." ".$amountDonated[$i];
                                                          ?></p>
                  </div>
                </div>
              </div>
        
              <?php
                $i=$i+1;
                if($i==$len){
              ?>
              </div>
              <container>      
              <?php    
                }
                else{
              ?>

              <div class="col-md-6">
                <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                  <div class="col p-4 d-flex flex-column position-static">
                  
                    <h3 class="mb-0"><?php 
                                      echo $name[$i];
                                      ?></h3>
                    <div class="mb-1 text-muted">From <?php echo $location[$i];?></div>
                    <p class="mb-auto">Donated <?php 
                                                echo $thingsDonated[$i]." ".$amountDonated[$i];
                                                ?></p>
                    <!-- <a href="#" class="stretched-link">Continue reading</a> -->
                  </div>
                </div>
              </div>
            </div>
          </container>
     </div>
    <?php } } } ?> 
     <!-- <div>
     <container>
      <div class="row mb-2 my-3 ml-3 mr-3" >
        <div class="col-md-6">
          <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
              <h3 class="mb-0">Rahul patil</h3>
              <div class="mb-1 text-muted">Nov 12</div>
              <p class="card-text mb-auto">Student from st.john college of engineering .</p>
              <a href="#" class="stretched-link">Continue reading</a>
            </div>
            
          </div>
        </div>
        <div class="col-md-6">
          <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
             
              <h3 class="mb-0">Anirudha tayade</h3>
              <div class="mb-1 text-muted">Nov 11</div>
              <p class="mb-auto">Employee at capegemini</p>
              <a href="#" class="stretched-link">Continue reading</a>
            </div>
           
          </div>
        </div>
      </div>
     </container>
     </div>

     <div>
     <container>
      <div class="row mb-2 my-3 ml-3 mr-3" >
        <div class="col-md-6">
          <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
             
              <h3 class="mb-0">Abhishek tiwari</h3>
              <div class="mb-1 text-muted">Nov 12</div>
              <p class="card-text mb-auto">A student from mumbai university</p>
              <a href="#" class="stretched-link">Continue reading</a>
            </div>
           
          </div>
        </div>
        <div class="col-md-6">
          <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
             
              <h3 class="mb-0">Rachit patil</h3>
              <div class="mb-1 text-muted">Nov 11</div>
              <p class="mb-auto">A farmer from dahanu</p>
              <a href="#" class="stretched-link">Continue reading</a>
            </div>
         
          </div>
        </div>
      </div>
     </container>
    </div>
    </div> -->
    
    <div class="cointainer bg-dark">
      <footer class="bd-footer text-muted">
        <div class="container-fluid p-2 p-md-3">
          <p>Currently all copyrights reserved to<a href="#"> @annapurna.com</a></p>
        </div>
      </footer>
    </div>

    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>



























