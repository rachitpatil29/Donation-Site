<?php
session_start();
$con = mysqli_connect('localhost','root');
if($con){

	echo "connection successful !!!!";

}else{

	echo "no connection";
}

$db = mysqli_select_db($con,'annapurna');

if(isset($_POST['submit'])){

	$username = $_POST['id'];
	$password = $_POST['pass'];

	$sql = "select * from ngo where id='$username' and pass='$password'";

	$query = mysqli_query($con,$sql);

	$row = mysqli_num_rows($query);

		if($row == 1){
			echo "login successful";
			$_SESSION['id'] = $username;

			header("location:http://localhost/annapurnafinal/ngoprofile.php");

		}else{
				echo "login failed";
				header('location:index.html');
			}


}

?>
