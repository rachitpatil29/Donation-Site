<?php
session_start();
$con = mysqli_connect('localhost','root');
if($con){

	echo "connection successful !!!!";

}else{

	echo "no connection";
}

$db = mysqli_select_db($con,'annapurna');

if(isset($_POST['submit'])){

	$tokennumber = $_POST['tokennumber'];
	$phonenumber = $_POST['phonenumber'];

	$sql = "select * from donors where tokennumber='$tokennumber' and phonenumber='$phonenumber'";

	$query = mysqli_query($con,$sql);

	$row = mysqli_num_rows($query);

		if($row == 1){
			echo "login successful";
			$_SESSION['id'] = $tokennumber;

			header("location:http://localhost/annapurnafinal/details.php?tokennumber=".$tokennumber);

		}else{
				echo "login failed";
				header('location:verify.html');
			}


}

?>
